print a

if b:    
    if c:
        d
    e
